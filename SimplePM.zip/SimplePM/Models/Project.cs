﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SimplePM.Models
{
    public class Project
    {
        public string Name { get; set; }

        public long Budget { get; set; }

        public long RunnintCost { get; set; }
    }
}