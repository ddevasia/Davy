﻿using SimplePM.DataBaseAccessLayer;
using SimplePM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SimplePM.Controllers
{
    public class EmployeesController : System.Web.Mvc.Controller
    {
        public void CreateEmployee([FromBody]Employee employee)
        {
            Repository repo = new Repository();
            repo.CreateEmployee(employee);
        }
    }
}
