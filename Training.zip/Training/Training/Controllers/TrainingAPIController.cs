﻿using Training.DBContext;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Training.Controllers
{
    public class TrainingAPIController : ApiController
    {
        protected readonly TrainingEntity TrainingDB = new TrainingEntity();
        public HttpResponseMessage Get()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            response.Content = new StringContent(JsonConvert.SerializeObject(TrainingDB.Trainings.AsEnumerable()), Encoding.UTF8, "application/json");
            return response;
        }

       public HttpResponseMessage Post([FromBody]Training.DBContext.Training value)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            TrainingDB.Trainings.Add(value);
            TrainingDB.SaveChanges();

            response.Content = new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");
            return response;                       
           
        }
       
    }
}
