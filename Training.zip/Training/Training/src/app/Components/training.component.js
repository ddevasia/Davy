"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var training_service_1 = require("../Service/training.service");
var forms_1 = require("@angular/forms");
var ng2_bs3_modal_1 = require("ng2-bs3-modal/ng2-bs3-modal");
var global_1 = require("../Shared/global");
var TrainingComponent = (function () {
    function TrainingComponent(fb, _trainingService) {
        this.fb = fb;
        this._trainingService = _trainingService;
        this.indLoading = false;
    }
    TrainingComponent.prototype.ngOnInit = function () {
        this.trainingFrm = this.fb.group({
            TrainingId: [''],
            TrainingName: ['', forms_1.Validators.required],
            StartDate: ['', forms_1.Validators.required],
            EndDate: ['', forms_1.Validators.required]
        });
        this.LoadTrainings();
    };
    TrainingComponent.prototype.LoadTrainings = function () {
        var _this = this;
        this.indLoading = true;
        this._trainingService.get(global_1.Global.BASE_USER_ENDPOINT)
            .subscribe(function (trainings) { _this.trainings = trainings; _this.indLoading = false; }, function (error) { return _this.msg = error; });
    };
    TrainingComponent.prototype.addUser = function () {
        this.SetControlsState(true);
        this.modalTitle = "Add New Training";
        this.modalBtnTitle = "Add";
        this.trainingFrm.reset();
        this.modal.open();
    };
    TrainingComponent.prototype.onSubmit = function (formData) {
        var _this = this;
        this.msg = "";
        if (formData._value.StartDate > formData._value.EndDate) {
            this.msg = global_1.Global.ERROR_MESSAGE_DATE;
        }
        else {
            this._trainingService.post(global_1.Global.BASE_USER_ENDPOINT, formData._value).subscribe(function (data) {
                if (data == 1) {
                    _this.msg = global_1.Global.SUCCESS_MESSAGE + ' ' + Math.ceil(Math.abs(formData._value.StartDate.getTime() - formData._value.EndDate.getTime()) / (1000 * 3600 * 24)) + ' Days Required for Training';
                    _this.LoadTrainings();
                }
                else {
                    _this.msg = global_1.Global.ERROR_MESSAGE;
                }
                _this.modal.dismiss();
            }, function (error) {
                _this.msg = error;
            });
        }
    };
    TrainingComponent.prototype.SetControlsState = function (isEnable) {
        isEnable ? this.trainingFrm.enable() : this.trainingFrm.disable();
    };
    return TrainingComponent;
}());
__decorate([
    core_1.ViewChild('modal'),
    __metadata("design:type", ng2_bs3_modal_1.ModalComponent)
], TrainingComponent.prototype, "modal", void 0);
TrainingComponent = __decorate([
    core_1.Component({
        templateUrl: 'app/Components/training.component.html'
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder, training_service_1.TrainingService])
], TrainingComponent);
exports.TrainingComponent = TrainingComponent;
//# sourceMappingURL=training.component.js.map