﻿export interface Training {
    TrainingId: number,
    TrainingName: string,
    StartDate: Date,
    EndDate: Date
}