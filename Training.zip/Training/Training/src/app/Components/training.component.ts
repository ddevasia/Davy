﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { TrainingService } from '../Service/training.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { Training } from '../Model/training';
import { Observable } from 'rxjs/Rx';
import { Global } from '../Shared/global';

@Component({
    templateUrl: 'app/Components/training.component.html'
})

export class TrainingComponent implements OnInit {

    @ViewChild('modal') modal: ModalComponent;
    trainings: Training[];
    training: Training;
    msg: string;
    indLoading: boolean = false;
    trainingFrm: FormGroup;    
    modalTitle: string;
    modalBtnTitle: string;

    constructor(private fb: FormBuilder, private _trainingService: TrainingService) { }

    ngOnInit(): void {
        this.trainingFrm = this.fb.group({
            TrainingId: [''],
            TrainingName: ['', Validators.required],
            StartDate: ['', Validators.required],
            EndDate: ['', Validators.required]
        });
        this.LoadTrainings();
    }

    LoadTrainings(): void {
        this.indLoading = true;
        this._trainingService.get(Global.BASE_USER_ENDPOINT)
            .subscribe(trainings => { this.trainings = trainings; this.indLoading = false; },
            error => this.msg = <any>error);
    }

    addUser() {        
        this.SetControlsState(true);
        this.modalTitle = "Add New Training";
        this.modalBtnTitle = "Add";
        this.trainingFrm.reset();
        this.modal.open();
    }    

    onSubmit(formData: any) {
        this.msg = "";   
        if (formData._value.StartDate > formData._value.EndDate)
        {
            this.msg = Global.ERROR_MESSAGE_DATE;
        }
        else{
        this._trainingService.post(Global.BASE_USER_ENDPOINT, formData._value).subscribe(
                    data => {
                        if (data == 1) //Success
                        {
                            this.msg = Global.SUCCESS_MESSAGE + ' ' + Math.ceil(Math.abs(formData._value.StartDate.getTime() - formData._value.EndDate.getTime())/ (1000 * 3600 * 24)) + ' Days Required for Training';
                            this.LoadTrainings();
                        }
                        else
                        {
                            this.msg = Global.ERROR_MESSAGE;
                        }
                        
                        this.modal.dismiss();
                    },
                    error => {
                      this.msg = error;
                    }
                );
         }          
    }

    SetControlsState(isEnable: boolean)
    {
        isEnable ? this.trainingFrm.enable() : this.trainingFrm.disable();
    }
}