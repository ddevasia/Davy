﻿using SimplePM.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SimplePM.DataBaseAccessLayer
{
    public class Repository
    {
        public List<Employee> GetEmployees()
        {
            try
            {
                SqlConnection sqlconn = new SqlConnection();
                sqlconn.ConnectionString = ConfigurationManager.ConnectionStrings[2].ToString();
                sqlconn.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Select * from Employee";
                sqlCommand.Connection = sqlconn;

                
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;
                DataSet ds = new DataSet();
                sqlDataAdapter.Fill(ds, "table1");

                return ((DataTable)ds.Tables[0]).AsEnumerable().Select(a => new Employee()
                {
                    FirstName = a.Field<string>("FirstName"),
                    LastName = a.Field<string>("LastName"),
                    Salary = a.Field<string>("Salary"),
                }).ToList();

            }
            catch(Exception ex)
            {

            }

            return null;
        }

        public List<Project> GetProjects()
        {
            try
            {
                SqlConnection sqlconn = new SqlConnection();
                sqlconn.ConnectionString = ConfigurationManager.ConnectionStrings[2].ToString();
                sqlconn.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Select Project.*,RunningCost=(Employee.Salary * EmployeeProjectAssignation.ParticipationRate) from Project inner join EmployeeProjectAssignation on Projects.Id=EmployeeProjectAssignation.ProjectId inner join Employee on EmployeeProjectAssignation.EmployeeId=Employee.Id";
                sqlCommand.Connection = sqlconn;


                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;
                DataSet ds = new DataSet();
                sqlDataAdapter.Fill(ds, "table1");

                return ((DataTable)ds.Tables[0]).AsEnumerable().Select(a => new Project()
                {
                    Name = a.Field<string>("Name"),
                    Budget = a.Field<int>("Budget"),
                    RunnintCost = a.Field<long>("RunningCost")
                }).ToList();

            }
            catch (Exception ex)
            {

            }

            return null;
        }

        public bool Validate(ProjectEmployeeAssignation employeeAssignation)
        {
            try
            {
                SqlConnection sqlconn = new SqlConnection();
                sqlconn.ConnectionString = ConfigurationManager.ConnectionStrings[0].ToString();
                sqlconn.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "select Budget from project where id =" + employeeAssignation.ProjectId + ";"+
                    "select Salary from Employee where id =" + employeeAssignation.EmployeeId + ";" +
                    "select sum(EmployeeProjectAssignation.ParticipationRate) as ParticiptionRate from EmployeeProjectAssignation  inner join Employee on EmployeeProjectAssignation.EmployeeId=Employee.Id where Employee.Id =" + employeeAssignation.EmployeeId + ";"+
                     "Select Sum(Employee.Salary * EmployeeProjectAssignation.ParticipationRate) as RunningCost from Project inner join EmployeeProjectAssignation on Project.Id=EmployeeProjectAssignation.ProjectId inner join Employee on EmployeeProjectAssignation.EmployeeId=Employee.Id group by project.id where Project.Id ="+employeeAssignation.ProjectId;
                
                sqlCommand.Connection = sqlconn;

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;
                DataSet ds = new DataSet();
                sqlDataAdapter.Fill(ds);

                var projectBudget = ((DataTable)ds.Tables[0]).AsEnumerable().Select(a => a.Field<long>("Budget")).FirstOrDefault();
                var employeeSalary = ((DataTable)ds.Tables[1]).AsEnumerable().Select(a => a.Field<int>("Salary")).FirstOrDefault();
                var employeeParticipationRate = ((DataTable)ds.Tables[2]).AsEnumerable().Select(a => a.Field<int>("ParticiptionRate")).FirstOrDefault();
                var projectRunningCost = ((DataTable)ds.Tables[3]).AsEnumerable().Select(a => a.Field<int>("RunningCost")).FirstOrDefault();

                //Employee Participation Rate is more than 100 % reject
                if (employeeParticipationRate > 100)
                {
                    return false;
                }

                //Running Cost + Employee Salary Would Exceed the budget allocated to project
                if( projectRunningCost + employeeSalary > projectBudget)
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

            }

            return true;
        }


        public void CreateProjects(Project project)
        {
            try
            {
                SqlConnection sqlconn = new SqlConnection();
                sqlconn.ConnectionString = ConfigurationManager.ConnectionStrings[0].ToString();
                sqlconn.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Insert into Project values("+ project.Name+","+project.Budget+")";
                sqlCommand.Connection = sqlconn;


                sqlCommand.ExecuteNonQuery();
                              
            }
            catch (Exception ex)
            {

            }
        }
        public void CreateEmployee(Employee employee)
        {
            try
            {
                SqlConnection sqlconn = new SqlConnection();
                sqlconn.ConnectionString = ConfigurationManager.ConnectionStrings[0].ToString();
                sqlconn.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Insert into Employee values(" + employee.FirstName + "," + employee.LastName + ","+employee.Salary+")";
                sqlCommand.Connection = sqlconn;


                sqlCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

            }
        }
        public void CreateProjectAssignation(ProjectEmployeeAssignation projectAssignation)
        {
            try
            {
                SqlConnection sqlconn = new SqlConnection();
                sqlconn.ConnectionString = ConfigurationManager.ConnectionStrings[0].ToString();
                sqlconn.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Insert into EmployeeProjectAssignation values(" + projectAssignation.EmployeeId + "," + projectAssignation.ProjectId + "," + projectAssignation.StartDate + ","+ projectAssignation.EndDate+","+ projectAssignation.ParticipationRate+")";
                sqlCommand.Connection = sqlconn;


                sqlCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

            }
        }
    }
}