﻿using SimplePM.DataBaseAccessLayer;
using SimplePM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;
using System.Web.Mvc;

namespace SimplePM.Controllers
{
    public class ProjectController : Controller
    {
        public List<Project> GetAllProjects()
        {
            Repository repo = new Repository();
            return repo.GetProjects();
        }

        // Create Project
        public void CreateProject([FromBody]Project project)
        {
            Repository repo = new Repository();
            repo.CreateProjects(project);
        }
    }
}
