﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SimplePM.Models
{
    public class ProjectEmployeeAssignation
    {
        public int EmployeeId
        {
            get;
            set;
        }

        public int ProjectId
        { 
            get;
            set;
        }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int ParticipationRate { get; set; }
    }
}