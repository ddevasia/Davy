import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { TrainingComponent } from './components/training.component';
import { TrainingService } from './Service/training.service'

@NgModule({
   imports: [BrowserModule,HttpModule],
   declarations: [AppComponent, TrainingComponent],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TrainingService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
